import PhotoViewer from './core';

export default PhotoViewer;
